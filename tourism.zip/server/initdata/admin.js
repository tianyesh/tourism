export default [{
  user_name: 'hans',
	password: '123456',
	id: 1,
	create_time: '',
	admin: '超级管理员',
	status: 2,  //1:普通管理、 2:超级管理员
	avatar: 'default.jpg',
	city: '北京',
}]
